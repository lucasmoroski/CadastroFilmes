﻿using Microsoft.EntityFrameworkCore;

namespace CadastFilme.Models
{
    public class Conexao:DbContext
    {
        public Conexao(DbContextOptions<Conexao> options) : base(options) {

        }

        public DbSet<Filme> Filmes { get; set; }
    }
}
