﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CadastFilme.Models
{
    public class Filme
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Por Favor Insira o Título do Filme.")]
        [DisplayName("Título do Filme")]
        public string Titulof { get; set; }

        [Required(ErrorMessage = "Por Favor Insira a Data de Lançamento do Filme.")]
        [DisplayName("Data de Lançamento do Filme")]
        public string Datalanc { get; set; }

        [Required(ErrorMessage = "Por Favor Insira uma Categoria.")]
        [DisplayName("Categoria/Genero do Filme")]
        public string Categoriafilme { get; set; }

        [Required(ErrorMessage = "Por Favor Insira o Nome do Diretor do Filme.")]
        [DisplayName("Diretor do Filme")]
        public string Nomediretor { get; set; }

        [DisplayName("Lista de Atores")]
        [MaxLength(5000)]
        public string ListaAtores { get; set; }

    }
}
